import firebase from 'firebase';

const firebaseConfig = {
  apiKey: "AIzaSyBWDGdlNrIb4QjWWg2P9t1JGC1eimbx84c",
  authDomain: "app-de-timbre-inalambric-1b2aa.firebaseapp.com",
  databaseURL: "https://app-de-timbre-inalambric-1b2aa-default-rtdb.firebaseio.com",
  projectId: "app-de-timbre-inalambric-1b2aa",
  storageBucket: "app-de-timbre-inalambric-1b2aa.appspot.com",
  messagingSenderId: "927720829216",
  appId: "1:927720829216:web:78e4aeb2542a1cd9a32745",
  measurementId: "G-0X9VJ7W7BT"
};

// Initialize Firebase
let app = firebase.initializeApp(firebaseConfig);
export default app.database();
